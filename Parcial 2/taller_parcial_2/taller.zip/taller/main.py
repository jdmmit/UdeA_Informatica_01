#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue May 20 19:35:01 2025

@author: daniel
"""

import module_manageDB as m_DB

Bandera = True
while(Bandera):
    print('Menu')
    print('-'*20)
    print('1. Agregar estudiante')
    print('2. Consultar información')
    print('3. Calcular la nota promedio')
    print('4. Salir')
    print('-'*20)
    
    opcion = input('Ingrese una opción: ')
    
    if opcion == '1':
        m_DB.add_student()
    if opcion == '2':

        m_DB.show_information()
        print('-'*20)
    if opcion == '3':
        m_DB.average_performance()
    elif opcion == '4':
        Bandera = False
    